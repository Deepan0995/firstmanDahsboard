import axios from "axios";
import React, { useState } from "react";
import SearchIcon from "@mui/icons-material/Search";

export default function SearchProduct() {
  const [name, setName] = useState("");
  const [product, setProduct] = useState(null);

  const handleSearch = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.get(
        `http://localhost:8080/getProductByName/${name}`
      );
      setProduct({ ...result.data });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="container p-2">
      <div className="card-header bg-warning text-center h3 p-2 my-3">
        Search Product By Name
      </div>
      <div className="card-body">
        <form onSubmit={handleSearch}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">
              Product Name :
            </label>
            <input
              type="text"
              className="form-control"
              id="name"
              name="name"
              placeholder="Customer Number"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-primary">
            <SearchIcon />
            Search
          </button>
        </form>
      </div>

      {product && (
        <table className="table table-hover table-bordered mt-5">
          <thead className="table-primary">
            <tr>
              <th>ID</th>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row" key={product.productId}>
                {product.productId}
              </th>
              <td>{product.productName}</td>
              <td>{product.quantity}</td>
              <td>{product.price}</td>
            </tr>
          </tbody>
        </table>
      )}
    </div>
  );
}
