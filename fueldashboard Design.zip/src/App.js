import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/css/bootstrap.min.css";

import { BrowserRouter } from "react-router-dom";

import MiniVariantDrawer from "./layout/MiniVariantDrawer";
import React from "react";

function App() {
  return (
    <React.StrictMode>
      <BrowserRouter>
        <MiniVariantDrawer />
      </BrowserRouter>
    </React.StrictMode>
  );
}

export default App;
