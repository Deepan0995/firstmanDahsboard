import axios from "axios";
import React, { useState } from "react";
import { Navigate } from "react-router-dom";

export default function LoginForm() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const credentials = {
      username: username,
      password: password,
    };

    axios
      .post(`http://localhost:8080/login`, credentials)
      .then((response) => {
        console.log(response.data); // Handle the success
        Navigate("/home");
      })
      .catch((error) => {
        console.error(error); // Handle the error response
      });
  };

  return (
    <div className="container-cover">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={handleUsernameChange}
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={handlePasswordChange}
          />
        </div>
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
